export default function NotFound() {
    return (
        <div>
            <h2>Page not found</h2>
        </div>
    )
}